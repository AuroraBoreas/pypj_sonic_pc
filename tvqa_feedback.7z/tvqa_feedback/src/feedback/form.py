from django.forms import ModelForm
from .models import Feed

class FeedRegisterForm(ModelForm):
    class Meta:
        model = Feed
        fields = [
            'title',
            'date_created',
            'feed',
        ]