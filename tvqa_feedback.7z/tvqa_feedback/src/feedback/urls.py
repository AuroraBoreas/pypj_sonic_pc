from .views import feed_create_view,contact_view, about_view, feed_list_view
from django.urls import path

app_name = 'feedback'

urlpatterns = [
    # path('home/', hello, name='home'),
    # path('', feed_create_view, name=''),
    # path('home/', home, name='home'),
    path('home/', feed_list_view, name='home'),
    path('feed/', feed_create_view, name='feed'),
    path('about/', about_view, name='about'),
    path('contact/', contact_view, name='contact'),
]