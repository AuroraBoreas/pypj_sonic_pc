import unittest
from unittest.mock import Mock

# The class to be tested
class MyClass:
    def __init__(self, dependency):
        self.dependency = dependency

    def my_method(self, data):
        result = self.dependency.some_method(data)
        # Perform some logic with the result
        return result

class TestMyClass(unittest.TestCase):
    def test_my_method(self) -> None:
        # Create a mock dependency
        mock_dependency = Mock()
        # Set the return value of the mocked method
        mock_dependency.some_method.return_value = 'mocked result'
        # Create an instance of the class being tested, passing the mock dependency
        my_instance = MyClass(mock_dependency)
        # Call the method being tested
        result = my_instance.my_method('some data')
        # Assert that the result is as expected
        self.assertEqual(result, 'mocked result')
        # Assert that the mocked method was called with the expected argument
        mock_dependency.some_method.assert_called_once_with('some data')

if __name__ == '__main__':
    unittest.main()