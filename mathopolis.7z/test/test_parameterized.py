import pytest

# The class to be tested
class Calculator:
    def add(self, a, b):
        return a + b

class TestCalculator:
    @pytest.mark.parametrize(
        'a, b, expected',
        [
            (2, 3, 5),
            (5, 7, 12),
            (-1, 1, 0),
        ]
    )
    def test_add(self, a, b, expected) -> None:
        # Create an instance of the Calculator class
        obj = Calculator()
        # Call the method being tested
        result = obj.add(a, b)
        # Assert that the result is equal to the expected value
        assert result == expected