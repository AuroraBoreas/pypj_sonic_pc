import unittest
import math
import sys
sys.path.append('.')

from lib.stats.zscore import ZScore

class TestZScore(unittest.TestCase):
    def setUp(self):
        #📐test setup
        self.zscore = ZScore(8, .8 * math.sqrt(10))
        print('set up')

    def test_calc_proba(self) -> None:
        self.assertGreater(self.zscore.calc_proba(10, 16, True), .27)
    
    def tearDown(self) -> None:
        print('tear down')

def suite() -> unittest.TestSuite:
    suite = unittest.TestSuite()
    suite.addTest(TestZScore('test_calc_proba'))
    # suite.addTest(TestZScore('test_another_thing'))
    return suite

def main() -> None:
    unittest.main()

if __name__ == '__main__':
    main()