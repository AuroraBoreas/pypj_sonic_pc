import math
from scipy import stats

class ZScore:
    def __init__(self, mean: float, sd: float) -> None:
        self._mean, self._sd = mean, sd

    def get_zscore(self, x: int) -> float:
        return (x - self._mean) / self._sd

    def calc_proba(
        self,
        low: int,
        high: int,
        inclusive: bool=False
    ) -> float:
        MARGIN: float = .5
        if inclusive:
            low_zscore  = self.get_zscore(low - MARGIN)
            high_zscore = self.get_zscore(high + MARGIN)
        else:
            low_zscore  = self.get_zscore(low)
            high_zscore = self.get_zscore(high)
        return stats.norm.cdf(high_zscore) - stats.norm.cdf(low_zscore)

def main() -> None:
    sd: float = .8 * math.sqrt(10)
    mean: int = 8
    obj: ZScore = ZScore(mean, sd)
    print(obj.calc_proba(10, 16, True))

if __name__ == '__main__':
    main()