from __future__ import annotations
import math

class Point:
    def __init__(self, x: int | float, y: int | float) -> None:
        self._x = x
        self._y = y
    
    @property
    def x(self) -> int | float:
        return self._x
    
    @property
    def y(self) -> int | float:
        return self._y
    
    def toPolar(self) -> tuple[int | float]:
        return (math.sqrt(self.x**2 + self.y**2), math.atan(self.y / self.x))
    
class Polar:
    def __init__(self, radius: int | float, angle: int | float) -> None:
        self._radius = radius
        self._angle  = angle

    def toCartesian(self) -> tuple[int | float]:
        return self._radius * math.cos(self._angle), self._radius * math.sin(self._angle)

class Vector:
    def __init__(self, p: Point) -> None:
        self._p = p

    @property
    def magnitude(self) -> int | float:
        return math.sqrt(self._p.x**2 + self._p.y**2)

    def angle(self) -> int | float:
        return math.atan(self._p.x / self.y)
    
    def __add__(self, other: Vector) -> Vector:
        return Vector(Point(self._p.x + other._p.x, self._p.y + other._p.y))
    
    def __sub__(self, other: Vector) -> Vector:
        return Vector(Point(self._p.x + other._p.x, self._p.y + other._p.y))
    
    def __mul__(self, other: Vector, angle_rad: int | float) -> Vector:
        return self.magnitude * other.magnitude * math.cos(angle_rad)