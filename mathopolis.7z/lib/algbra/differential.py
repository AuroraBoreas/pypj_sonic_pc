
from abc import ABCMeta, abstractmethod


class OrderEqn(metaclass=ABCMeta):
    @abstractmethod
    def get_general_form(self) -> str:
        raise NotImplementedError
    
    @abstractmethod
    def get_general_form_of_solution(self) -> str:
        raise NotImplementedError

    @abstractmethod
    def get_hint(self) -> str:
        raise NotImplementedError

class Fode(OrderEqn):
    def __init__(self) -> None:
        pass

    def get_general_form_of_solution(self) -> str:
        return "Fode sln     : y = 1/v * \u222B(v * Q(x))dx"

    def get_general_form(self) -> str:
        return "Fode         : y\u2032 + P(x) * y = Q(x)"
    
    def get_hint(self) -> str:
        return "hint         : (uv)\u2032 = u\u2032v + uv\u2032"

class Sode(OrderEqn):
    def __init__(self) -> None:
        pass

    def get_general_form_of_solution(self) -> str:
        return "Sode sln     : Undetermined Coefficients, Variation of Parameters"
    
    def get_general_form(self) -> str:
        return "Sode         : y\u2033 + P(x) * y\u2032 + Q(x) * y = f(x)"
    
    def get_homogeneous_form(self) -> str:
        return "Sode(homo)   : y\u2033 + P(x) * y\u2032 + Q(x) * y = 0"
    
    def get_nonhomogeneous_form(self) -> str:
        return "Sode(nhomo)  : y\u2033 + P(x) * y\u2032 + Q(x) * y = f(x)"
    
    def get_euler_formula(self) -> str:
        return "e^(ix) = cos(x) + i * sin(x)"
    
    def get_hint(self) -> str:
        return "hint         : f(x) = e^(rx)"

class Bernoulli(OrderEqn):
    def __init__(self) -> None:
        pass

    def get_general_form_of_solution(self) -> str:
        return "Bernoulli sln: u\u2032 + P * (1-n) * u = Q * (1-n)"
    
    def get_general_form(self) -> str:
        return "Bernoulli    : y\u2032 + P(x) * y = Q(x) * y\u207F"
    
    def get_hint(self) -> str:
        return "hint         : u = y^(1-n)"

def client_code(list: list[OrderEqn]) -> None:
    for eqn in list:
        print("=" * 50)
        print(eqn.get_general_form())
        print(eqn.get_hint())
        print(eqn.get_general_form_of_solution())

def main() -> None:
    client_code([Fode(), Sode(), Bernoulli()])

if __name__ == '__main__':
    main()