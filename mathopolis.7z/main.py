from __future__ import annotations

from lib.stats.birthday import SharedBirthdayProbability

def main() -> None:
    sbp: SharedBirthdayProbability = None
    for item in [
        (11, 365),
        (50, 365),
        (60, 365),
        (70, 365),
        (7, 10),
        (8, 26),
        (6, 7),
        (8, 12),
    ]:
        sbp = SharedBirthdayProbability(*item)
        print(sbp)

if __name__ == '__main__':
    main()