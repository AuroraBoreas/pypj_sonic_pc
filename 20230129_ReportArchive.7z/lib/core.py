from __future__ import annotations
import contextlib
import logging
import pathlib
import re
import yaml
import sqlite3
from typing import Optional, Self, TypeVar, NewType

Path       = TypeVar('Path', str, bytes, pathlib.Path)
Connection = NewType('Connection', sqlite3.Connection)
Cursor     = NewType('Cursor', sqlite3.Cursor)
T          = TypeVar('T', int, str, bool)

logging.basicConfig(level=logging.INFO, format='%(message)s')

@contextlib.contextmanager
def enter_table(conn: Connection) -> Cursor:
    cur: Cursor = conn.cursor()
    try:
        yield cur
    finally:
        cur.close()

class Archiver:
    __srcFolders: list[Path] = None

    def scout(self, config: Path) -> Self:
        with open(config, 'r', encoding='utf8') as f:
            self.__srcFolders = yaml.safe_load(f)['srcFolders']
        return self

    def _read_src_files(self, folder: Path) -> Optional[Path]:
        """Enumerate all xxx.pptx files from a given root directory recursively

        Parameters
        ----------
        folder
            a given root directory

        Returns
        -------
            a Path like str
        """
        files   = pathlib.Path(folder).rglob(r'*.pptx')
        pattern = r'^[0-9]{8}.*\.pptx'
        for file in files:
            res = re.match(pattern, file.name)
            if res:
                yield file

    def _fileToBytes(self, fromFile: Path) -> bytes:
        with open(fromFile, 'rb') as f:
            return f.read()

    def _bytesToFile(self, data: bytes, toFile: Path) -> None:
        with open(toFile, 'wb') as f:
            f.write(data)

    def _strToDate(self, date: str) -> str:
        return f"{date[:4]}-{date[4:6]}-{date[6:]}"
    
    def dump(self, db: Path) -> None:
        sql_stmt_create: str = """CREATE TABLE IF NOT EXISTS report(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            date VARCHAR(10),
            topic VARCHAR(20),
            name VARCHAR(50),
            file BLOB,

            UNIQUE(date, topic, name) ON CONFLICT IGNORE
        );"""

        sql_stmt_insert: str = """INSERT INTO report(date, topic, name, file)
            VALUES(?,?,?,?);"""
            
        if not db:
            raise ValueError

        with sqlite3.connect(db) as conn:
            with enter_table(conn) as cur:
                cur.execute(sql_stmt_create)
                for src_folder in self.__srcFolders:
                    for file in self._read_src_files(src_folder):
                        try:
                            temp: list[str] = file.name.split('_')
                            date: str       = self._strToDate(temp[0])
                            topic: str      = temp[1]
                            name: str       = ' '.join(temp[2:]).replace('.pptx','')
                            cur.execute(sql_stmt_insert, (date, topic, name, self._fileToBytes(file)))
                            logging.info(f"[Archive OK] file: {file.name}")
                        except IndexError:
                            conn.rollback()

    def retrieve(self, start: str,
        end: str,
        topic: str,
        id: int,
        db: Path=None,
        dstFolder: Path=None) -> None:
        
        sql_stmt_retrieve: str = None
        args: tuple[T]         = None

        if not db:
            raise ValueError

        if topic == '*':
            sql_stmt_retrieve = """SELECT * FROM report
            WHERE date >= ? AND date <= ?;
            """
            args = (start, end)
        else:
            if id != -1:
                sql_stmt_retrieve = """
                SELECT * FROM report
                WHERE date >= ? AND date <= ? AND topic LIKE ? AND id=?;
                """
                args = (start, end, topic, id)
            else:
                sql_stmt_retrieve = """
                SELECT * FROM report
                WHERE date >= ? AND date <= ? AND topic LIKE ?;
                """
                args = (start, end, topic)

        idIdx: int    = 0
        dateIdx: int  = 1
        topicIdx: int = 2
        fileIdx: int  = 4
        counter: int  = 0
        fmt: str             = "{0:<10}\t{1:<10}\t{2:<15}\t{3}"
        heads: tuple[str]    = ('id', 'Date','Topic','Name')
        punchline: list[str] = ["\N{BOX DRAWINGS HEAVY HORIZONTAL}" * 10] * 4

        with sqlite3.connect(db) as conn:
            with enter_table(conn) as cur:
                rows = cur.execute(sql_stmt_retrieve, args)
                logging.info(fmt.format(*heads))
                logging.info(fmt.format(*punchline))
                for row in rows:
                    counter += 1
                    logging.info(fmt.format(*row[idIdx : fileIdx]))
                    if dstFolder:
                        self._bytesToFile(
                            row[fileIdx],
                            "{0}\{1}_{2}.pptx".format(
                                dstFolder,
                                row[dateIdx].replace('-',''),
                                ' '.join(row[topicIdx : fileIdx]).replace('  ',' ').replace(' ','_')
                            )
                        )
                logging.info(punchline[0])
                logging.info(f"total: {counter}")