from core import Path, pathlib, logging, re, shutil
from typing import Generator

roots: list[Path] = [
    r"\\43.98.1.18\SSVE_Division\SHES-C\部共通\03-Info-Share\03-FYxx Model\FY19_Model",
    r"\\43.98.1.18\SSVE_Division\SHES-C\部共通\03-Info-Share\03-FYxx Model\FY20_Model",
    r"\\43.98.1.18\SSVE_Division\SHES-C\部共通\03-Info-Share\03-FYxx Model\FY21_Model",
]

def forage(root: Path) -> None:
    files: Generator[Path, None, None] = pathlib.Path(root).rglob("*.pptx")
    pattern: str = r"[0-9]{8}[\s_]"
    for file in files:
        if re.match(pattern, file.name):
            logging.info(file.name)
            shutil.copyfile(file, '..\\data\\' + file.name.replace(' ', '_'))

def main() -> None:
    for root in roots:
        forage(root)

if __name__ == '__main__':
    main()
