
from typing import overload


@overload
def add(a: int, b: int) -> int: ...

@overload
def add(a: float, b: float) -> float: ...

@overload
def add(a: str, b: str) -> str: ...

def add(a: int | float | str, b: int | float | str) -> int | float | str:
    return a + b

def main() -> None:
    print(add(1, 2))

if __name__ == '__main__':
    main()



