
from typing import overload


@overload
def add(a: int, b: int) -> int: ...

@overload
def add(a: float, b: float) -> float: ...

@overload
def add(a: str, b: str) -> str: ...

def add(a: int | float | str, b: int | float | str) -> int | float | str:
    if any(isinstance(x, str) for x in [a, b]):
        return f"{a} {b}"
    return a + b

def main() -> None:
    print(add(1, 2))

if __name__ == '__main__':
    main()



