# Quality Report Archiver Application

This CLI application is to search and archive all quality resports, and orgnize query plan.

## Changelog

- v0.01, 20230129, initial build
- v0.02, 20230130, bugfix
- v0.03, 20230203, bugfix
- v0.04, refactor and optimize query
- v0.05, 20230215, hackle my memories and document this project

## Author

@ZL, SSVE TVQA member

## Project structure

```Batch
X:.
│  config.yaml
│  main.py
│  QRA.db
│  QRA.exe.lnk
│  requirements.txt
│
├─data
├─doc
│      QRA.md
│
├─lib
│      core.py
│      test.py
│      util.py
│      __init__.py
│
├─reports
└─scripts
        cmd.bat
        env.bat
        env_for_icons.bat
        QRA.exe
```

## Implementation

The following is the detail of implementation.

### Build portable CLI interface

After reverse-engineering WinPython, I found a general approach to build portable interfaces for any compilers.

Accredit to WinPython team for this!

### Create core functionality

```Python
class Archiver:
    __srcFolder: list[Path] = None
    __db: Path              = None
    __dstFolder: Path       = None

    def __init__(self, config: Path) -> None: ...

    def _scout(self, config: Path) -> None: ...

    def _read_src_files(self, folder: Path) -> Optional[Path]: ...

    def _fileToBytes(self, fromFile: Path) -> bytes: ...

    def _bytesToFile(self, data: bytes, toFile: Path) -> None: ...

    def _strToDate(self, date: str) -> str: ...
    
    def dump(self) -> None: ...

    def _sql_dll_stmt(self) -> tuple[str, str]: ...

    def retrieve(self,
        start: str,
        end: str,
        topic: str,
        name: str,
        id: int,
        save: bool) -> None: ...

    def _parse_sql_stmt(self,
        start: str,
        end: str,
        topic: str,
        name: str,
        id: int) -> tuple[str, tuple[T]]: ...

    def _reset(self, dstFolder: Path=None) -> None: ...

    def _save(self,
        row: tuple[int | str | bytes],
        dateIdx: int,
        topicIdx: int,
        fileIdx: int) -> None:...
```

### Optimize query plan

```SQL

> sqlite3
sqlite> .open "X:\\directory\\to\\project\\QRA.db"
sqlite> .tables
sqlite> CREATE INDEX IF NOT EXISTS idIndex ON report (id ASC);
sqlite> CREATE INDEX IF NOT EXISTS dateIndex ON report (date ASC);
sqlite> .exit

```

### CLI App Demo

#### Help

```Batch
> python main.py --help
Usage: main.py [OPTIONS]

  this Python CLI app interacts with a sqlite3 database to write / read data
  and info.

  Changelog: v0.05

  Author: @ZL, 20230129

Options:
  --upload BOOLEAN  do you wanna archive local reports to database?
  --start TEXT      start date
  ...               ...
  --topic TEXT      search topic (*1st specificity)
```

#### Search by Topic

```Batch
> python main.py --topic FH
id              Date            Topic           Name
━━━━━━━━━━      ━━━━━━━━━━      ━━━━━━━━━━      ━━━━━━━━━━
278             2022-01-20      AX&FT&FH85      DP SSVE
295             2022-03-17      FH75            LED Fail SSVE PP
319             2022-05-18      FH85            Foreign Material FSK PP v0.11
...             ...             ...             ...
376             2022-12-08      FH75            LENS Drop FSK MP v0.03
━━━━━━━━━━
total: 26
```

#### Search by Name

```Batch
> python main.py --name line
id              Date            Topic           Name
━━━━━━━━━━      ━━━━━━━━━━      ━━━━━━━━━━      ━━━━━━━━━━
42              2019-11-26      NX75            MVT Dust confirmation inline
45              2019-12-02      SOEM            ITC confirmation inline
106             2020-09-14      NX85            SOEM WhiteLine FA
...             ...             ...             ...
356             2022-09-26      FH85            AX85 H-White Line Comparison
━━━━━━━━━━
total: 23
```

#### Search by Id

```Batch
> python main.py --name line --id 346
id              Date            Topic           Name
━━━━━━━━━━      ━━━━━━━━━━      ━━━━━━━━━━      ━━━━━━━━━━
346             2022-08-22      FW85            QA V-line FSK PP v0.01
━━━━━━━━━━
total: 1
```

## About

MIT License

Copyright (c) 2023 ZL

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
