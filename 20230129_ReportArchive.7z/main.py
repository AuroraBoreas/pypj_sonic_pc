from lib.core import Path, Archiver, pathlib
import click
import shutil

@click.command()
@click.option('--upload', default=False, help='do you wanna archive local reports to database?')
@click.option('--start', default='2019-01-01', help='start date')
@click.option('--end', default='2099-12-31', help='end date')
@click.option('--topic', default='*', help='search topic (*1st specificity)')
@click.option('--id', default=-1, help='search id (*2nd specificity)')
@click.option('--save', default=False, help='save to local `reports` directory?')
def main(upload: bool, start: str, end: str, topic: str, id: int, save: bool) -> None:
    """this Python CLI app interacts with a sqlite3 database to write / read data and info. 
    
    Changelog: v0.03

    Author: @ZL, 20230129
    """

    config: Path       = 'config.yaml'
    db: Path           = "QRA.db"
    dstFolder: Path    = "reports"
    archiver: Archiver = Archiver()

    if upload:
        archiver.scout(config).dump(db)
    else:
        query(dstFolder, start, end, topic, id, save, db, archiver)

def query(dstFolder: str,
    start: str,
    end: str,
    topic: str,
    id: int,
    save: bool,
    db: str,
    archiver: Archiver) -> None:
    
    if not save:
        dstFolder = None
    else:
        p: Path = pathlib.Path(dstFolder)
        if p.exists(): shutil.rmtree(p)
    
    if dstFolder and (not pathlib.Path(dstFolder).exists()):
        pathlib.Path(dstFolder).mkdir()
    
    archiver.retrieve(start, end, topic, id, db, dstFolder)

if __name__ == '__main__':
    main()