from lib import Path, Archiver
import click

@click.command()
@click.option('--upload', default=False, help='do you wanna archive local reports to database?')
@click.option('--start', default='2019-01-01', help='start date')
@click.option('--end', default='2099-12-31', help='end date')
@click.option('--topic', default='*', help='search topic (*1st specificity)')
@click.option('--name', default='*', help='search file name')
@click.option('--id', default=-1, help='search id (*2nd specificity)')
@click.option('--save', default=False, help='save to local `reports` directory?')
def main(upload: bool, start: str, end: str, topic: str, name: str, id: int, save: bool) -> None:
    """This Python CLI app interacts with a database to write / read data and info. 
    
    Changelog: v0.05

    Author: @ZL, 20230129
    """
    config: Path       = 'config.yaml'
    archiver: Archiver = Archiver(config=config)

    if upload:
        archiver.dump()
    else:
        archiver.retrieve(start, end, topic, name, id, save)

if __name__ == '__main__':
    main()