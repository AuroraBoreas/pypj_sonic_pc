
from library.core import (
    PBM_FileStruct,
    PBM_Wrangler, 
    Holder, 
)

import os
import tkinter as tk
from tkinter import filedialog

def main()->None:
    root = tk.Tk()
    root.withdraw()
    fd_path = filedialog.askdirectory()
    if os.path.isdir(fd_path):
        pfs:PBM_FileStruct = PBM_FileStruct()
        holder: Holder     = Holder()
        offset:float       = .0        
        pw = PBM_Wrangler(pfs, fd_path, holder, offset)
        pw.work('./data/wb.db', 'wb')
    root.destroy()

if __name__ == '__main__':
    main()