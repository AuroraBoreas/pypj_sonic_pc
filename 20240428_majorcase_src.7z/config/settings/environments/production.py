from config.settings.environments.base import *

DEBUG = False
ALLOWED_HOSTS += [
    '127.0.0.1',
]

DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.postgresql",
        "OPTIONS": {
            "service": "my_service",
            "passfile": ".my_pgpass",
        },
    }
}