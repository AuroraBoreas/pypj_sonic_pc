# from .base import *
from config.settings.environments.base import *

DEBUG = True
ALLOWED_HOSTS += [
    '43.98.120.31',
]

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}


