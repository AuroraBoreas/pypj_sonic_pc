from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('core.mqc.urls', namespace='mqc')),
    path('user/', include('core.user.urls', namespace='user')),
    path('__debug__/', include('debug_toolbar.urls')),
]

admin.site.site_header = 'Administration'
admin.site.site_title = 'Explore'
admin.site.index_title = 'Welcome To The Admin Panel'
