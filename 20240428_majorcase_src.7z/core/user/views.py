from django.http import HttpRequest, HttpResponse
from django.shortcuts import render, redirect
from .forms import AppUserRegisterForm
from django.contrib import messages

from django.contrib.auth.decorators import login_required

def register(request: HttpRequest) -> HttpResponse:
    if request.method == 'POST':
        form = AppUserRegisterForm(request.POST or None)
        if form.is_valid():
            form.save()
            messages.success(request, 'Your account has been created! You are now able to login')
            return redirect('mqc:dashboard')
    else:
        form = AppUserRegisterForm()
    return render(request, 'core/user/register.html', context={'form':form})

from django.contrib import auth
from django.contrib.auth.decorators import login_required

@login_required
def logout(request: HttpRequest) -> HttpResponse:
    auth.logout(request)
    return render(request, 'core/user/login.html')