from core.mqc.models import (
    Department,
    ResponsibilityCategory,
    PartCategory,
    Location,
    DivisionCategory,
    MajorQualityCase,
)

from django.db import connection
from pprint import pprint
from django.db.models import Count, Value, F, Q
from django.db.models.functions import ExtractMonth, TruncMonth
import calendar
from django.utils import timezone
from collections import OrderedDict


def run() -> None:
    field = '責区__name'
    objs = (
        MajorQualityCase.objects
            .filter(責区__isnull=False)
            .values(field)
            .annotate(
                product=F(field),
                n=Count('pk')
            )
    )
    print(objs)
    pprint(connection.queries)
