from django.contrib import admin

from .models import (
    MajorQualityCase,
    PartCategory,
    Department,
    Location,
    ResponsibilityCategory
)


admin.site.register(MajorQualityCase)
admin.site.register(PartCategory)
admin.site.register(Department)
admin.site.register(ResponsibilityCategory)
admin.site.register(Location)

from import_export import resources, fields

class MajorQualityCaseResource(resources.ModelResource):
    # genre = fields.Field()
    # def dehydrate_genre(self, obj: MajorQualityCase):
    #     match obj.genre:
    #         case MajorQualityCase.GenreChoices.CRIME:
    #             return 'Crime'
    #         case MajorQualityCase.GenreChoices.SCI_FI:
    #             return 'Sci-Fi'
    #         case MajorQualityCase.GenreChoices.NON_FICTION:
    #             return 'Non_Fiction'
    #         case _:
    #             return 'Other'
    class Meta:
        model = MajorQualityCase
        fields = (
            'id',
            '進捗',
            # '市場発生',
            # '再発防止',
            # '出荷停止',
            '責区__name',
            '責任者__username',
            # 'TAT',
            '製品分__name',
            '分類__name',
            '案件名',
            '機種名型番',
            # '進捗状況',
            '発生場所__name',
            '発生日',
            '不良症状内容',
            # '保留対象',
            # '依頼日',
            # '停止日',
            # '解除日',
            # '単品在庫',
            # '半製品在庫',
            # '完成品在庫',
            # '外部在庫',
            # '対応内容',
            # '実施予定日',
            # '実施実際日',
            # '実施部署__name',
            # '実施者__username',
            # '発生原因',
            # '流出原因',
            # 'なぜなぜ',
            # '分析完了予定日',
            # '分析完了実際日',
            # '是正処置発生対策',
            # '是正処置流出対策',
            # '是正処置再発防止',
            # '是正完了予定日',
            # '是正完了実際日',
            'CLOSE日',
        )
        # export_order = (
        #     '進捗',
        #     '発生日',
        #     '案件名',
        #     '発生場所',
        #     '不良症状内容',
        #     '責任者__username',
        # )