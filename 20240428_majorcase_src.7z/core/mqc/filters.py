import django_filters
from .models import MajorQualityCase
from crispy_forms.helper import FormHelper
from crispy_forms.layout import Layout, Div, Field, Fieldset

class MajorQualityCaseFilter(django_filters.FilterSet):
    進捗 = django_filters.RangeFilter(field_name='進捗')
    # TAT = django_filters.RangeFilter(field_name='TAT')
    発生日 = django_filters.DateFromToRangeFilter(field_name='発生日')
    CLOSE日 = django_filters.DateFromToRangeFilter(field_name='CLOSE日')

    class Meta:
        model = MajorQualityCase
        fields = {
            'id': ['exact'],
            # '市場発生': ['exact'],
            # '再発防止': ['exact'],
            # '出荷停止': ['exact'],
            '責区': ['exact'],
            '責任者': ['exact'],
            # 'TAT': [],
            '製品分': ['exact'],
            '分類' : ['exact'],
            '案件名': ['icontains'],
            '機種名型番': ['icontains'],
            # '進捗状況': ['icontains'],
            '発生場所': ['exact'],
            '不良症状内容': ['icontains'],
            # '保留対象': [],
            # '依頼日': [],
            # '停止日': [],
            # '解除日': [],
            # '単品在庫': [],
            # '半製品在庫': [],
            # '完成品在庫': [],
            # '外部在庫': [],
            # '対応内容': [],
            # '実施予定日': [],
            # '実施実際日': [],
            # '実施部署': [],
            # '実施者': [],
            # '発生原因': [],
            # '流出原因': [],
            # 'なぜなぜ': [],
            # '分析完了予定日': [],
            # '分析完了実際日': [],
            # '是正処置発生対策': [],
            # '是正処置流出対策': [],
            # '是正処置再発防止': [],
            # '是正完了予定日': [],
            # '是正完了実際日': [],
            # 'CLOSE日': [],
        }