import typing

from django.contrib import messages
from django.http import HttpRequest, HttpResponse
from django.shortcuts import get_object_or_404, render
from django.urls import reverse
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic import (CreateView, UpdateView, DetailView, DeleteView, ListView, FormView)
from django.db import models

from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.generics import ListAPIView

from .admin import MajorQualityCaseResource
from .models import (
    MajorQualityCase,
    get_dataset_per_location,
    get_dataset_per_month_of_current_year,
    get_dataset_per_division,
    get_dataset_per_partCategory,
    get_dataset_per_responsibility,
    get_dataset_per_department,
)
from .forms import (MajorQualityCaseForm, MajorQualityCaseDownloadFormatForm)
from .filters import MajorQualityCaseFilter
from .serializers import MajorQualityCaseSerializer

def index(request: HttpRequest) -> HttpResponse:
    return render(request, 'core/mqc/index.html', context={})

def dashboard(request: HttpRequest) -> HttpResponse:
    context = {
        'dataset_per_monthOfCurrentYear': get_dataset_per_month_of_current_year(),
        'dataset_per_division': get_dataset_per_division(),
        'dataset_per_partCategory': get_dataset_per_partCategory(),
        'dataset_per_responsibility': get_dataset_per_responsibility(),
        'dataset_per_department': get_dataset_per_department(),
        'dataset_per_location': get_dataset_per_location(),
    }
    return render(request, 'core/mqc/dashboard.html', context=context)

class MajorQualityCaseFilterListView(ListView, FormView):
    queryset = MajorQualityCase.objects.all()
    template_name = 'core/mqc/data.html'
    context_object_name = 'cases'
    form_class = MajorQualityCaseDownloadFormatForm
    paginate_by = 10

    def get_queryset(self):
        queryset = super().get_queryset()
        self.filterset = MajorQualityCaseFilter(self.request.GET, queryset=queryset)
        return self.filterset.qs

    def get_context_data(self, **kwargs: typing.Any):
        context = super().get_context_data(**kwargs)
        context['filterform'] = self.filterset.form
        context.update(get_dataset_per_location())
        return context

    def post(self, request: HttpRequest, *args: typing.Any, **kwargs: typing.Any) -> HttpResponse:
        # qs = self.get_queryset()
        dataset = MajorQualityCaseResource().export()
        format = request.POST.get('format')
        match format:
            case 'csv':
                ds = dataset.csv
            case 'xls':
                ds = dataset.xls
            case _:
                ds = dataset.json
        response = HttpResponse(ds, content_type=format)
        response['Content-Disposition'] = f'attachment; filename=data.{format}'
        return response

class MajorQualityCaseListAPIView(LoginRequiredMixin, ListAPIView):
    queryset = MajorQualityCase.objects.all()
    serializer_class = MajorQualityCaseSerializer
    filter_backends = (DjangoFilterBackend,)
    login_url = None
    
    def get_login_url(self) -> str:
        self.login_url = reverse('user:login')
        return super().get_login_url()

class MajorQualityCaseCreateView(LoginRequiredMixin, CreateView):
    template_name = 'core/mqc/create.html'
    form_class = MajorQualityCaseForm
    login_url = None
    
    def get_login_url(self) -> str:
        self.login_url = reverse('user:login')
        return super().get_login_url()

    def post(self, request: HttpRequest, *args: str, **kwargs: typing.Any) -> HttpResponse:
        form = MajorQualityCaseForm(request.POST or None)
        if form.is_valid():
            messages.success(self.request, 'Created successfully')
            form.save()
            form = MajorQualityCaseForm()
        return render(request, self.template_name, context={'form':form})

class MajorQualityCaseUpdateView(LoginRequiredMixin, UpdateView):
    model = MajorQualityCase
    template_name = 'core/mqc/create.html'
    form_class = MajorQualityCaseForm
    login_url = None
    
    def get_login_url(self) -> str:
        self.login_url = reverse('user:login')
        return super().get_login_url()
    
    def get_object(self) -> models.base.Model:
        pk = self.kwargs.get('pk')
        return get_object_or_404(self.model, id=pk)

    def form_valid(self, form) -> HttpResponse:
        messages.success(self.request, 'Updated successfully')
        form.save()
        return super().form_valid(form)

class MajorQualityCaseDetailView(DetailView):
    template_name = 'core/mqc/detail.html'
    model = MajorQualityCase

    def get_object(self) -> models.base.Model:
        pk = self.kwargs.get('pk')
        return get_object_or_404(self.model, id=pk)

class MajorQualityCaseDeleteView(LoginRequiredMixin, DeleteView):
    template_name = 'core/mqc/delete.html'
    model = MajorQualityCase
    login_url = None
    
    def get_login_url(self) -> str:
        self.login_url = reverse('user:login')
        return super().get_login_url()

    def is_superuser(self) -> bool:
        return self.request.user.is_superuser
    
    def dispatch(self, request: HttpRequest, *args: typing.Any, **kwargs: typing.Any) -> HttpResponse:
        if not self.is_superuser():
            return self.handle_no_permission()
        return super().dispatch(request, *args, **kwargs)
    
    def delete(self, request: HttpRequest, *args: typing.Any, **kwargs: typing.Any) -> HttpResponse:
        messages.info(request, 'Delete successfully')
        return super().delete(request, *args, **kwargs)

    def get_object(self) -> models.base.Model:
        pk = self.kwargs.get('pk')
        return get_object_or_404(self.model, id=pk)

    def get_success_url(self) -> str:
        return reverse('mqc:dataset')