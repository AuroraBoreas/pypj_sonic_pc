from django import forms
from .models import (
    MajorQualityCase,
    PartCategory,
    Department,
    ResponsibilityCategory
)

class PartCategoryForm(forms.ModelForm):
    class Meta:
        model = PartCategory
        fields = '__all__'

class DepartmentForm(forms.ModelForm):
    class Meta:
        model = Department
        fields = '__all__'

class ResponsibilityCategoryForm(forms.ModelForm):
    class Meta:
        model = ResponsibilityCategory
        fields = '__all__'

class DateInputWidget(forms.DateInput):
    input_type = 'date'

class MajorQualityCaseForm(forms.ModelForm):
    class Meta:
        model = MajorQualityCase
        fields = '__all__'
        widgets = {
            '発生日': DateInputWidget(), 
            '依頼日': DateInputWidget(),
            '停止日': DateInputWidget(),
            '解除日': DateInputWidget(),
            '実施予定日': DateInputWidget(),
            '実施実際日': DateInputWidget(),
            '分析完了予定日': DateInputWidget(),
            '分析完了実際日': DateInputWidget(),
            '是正完了予定日': DateInputWidget(),
            '是正完了実際日': DateInputWidget(),
            'CLOSE日': DateInputWidget(),
            '進捗': forms.TextInput(attrs={'placeholder': '0-100'}),
        }

class MajorQualityCaseDownloadFormatForm(forms.Form):
    FormatChoices = [
        ('csv', 'csv'),
        ('xls', 'xls'),
        ('json', 'json'),
    ]
    format = forms.ChoiceField(
        choices=FormatChoices,
        widget=forms.Select(attrs={'class':'form-select'})
    )
