from tabnanny import verbose
import typing
from unicodedata import category
from django.db import models
from django.core.validators import MaxValueValidator, MinValueValidator
from django.db.models import Count, F

from auditlog.registry import auditlog
from auditlog.models import AuditlogHistoryField
from django.urls import reverse

from core.user.models import AppUser

class Department(models.Model):
    name = models.CharField(max_length=25, null=False, blank=False)    
    class Meta:
        verbose_name_plural = 'Departments'
    def __str__(self) -> str:
        return self.name

class ResponsibilityCategory(models.Model):
    name = models.CharField(max_length=100, null=False, blank=False)
    class Meta:
        verbose_name_plural = 'Categories'
    def __str__(self) -> str:
        return self.name
    
class PartCategory(models.Model):
    name = models.CharField(max_length=15, null=False, blank=False)
    class Meta:
        verbose_name_plural = 'PartCategories'
    def __str__(self) -> str:
        return self.name

class Location(models.Model):
    name = models.CharField(max_length=15, null=False, blank=False)
    class Meta:
        verbose_name_plural = 'Locations'
    def __str__(self) -> str:
        return self.name

class DivisionCategory(models.Model):
    name = models.CharField(max_length=15, null=False, blank=False)
    class Meta:
        verbose_name_plural = 'DivisionCategories'
    def __str__(self) -> str:
        return self.name

class MajorQualityCase(models.Model):
    progress = models.FloatField(
        validators=[
            MinValueValidator(0),
            MaxValueValidator(100)
        ],
        null=True,  blank=True, name='進捗'
    )
    market = models.BooleanField(null=True, default=False, name='市場発生')
    reoccurrence = models.BooleanField(null=True, default=False, name='再発防止')
    shipmentStop = models.BooleanField(null=True, default=False, name='出荷停止')
    responsibleCategory = models.ForeignKey(
        ResponsibilityCategory, on_delete=models.DO_NOTHING,
        null=True, blank=False, name='責区',
    )
    responsibleUser = models.ForeignKey(
        AppUser, on_delete=models.DO_NOTHING,
        null=True, blank=True, related_name='責任者', name='責任者'
    )
    tat = models.CharField(max_length=255, null=False, blank=True, name='TAT')
    partCategory = models.ForeignKey(
        PartCategory, on_delete=models.DO_NOTHING,
        null=True, blank=False, name='製品分'
    )
    divisionCategory = models.ForeignKey(
        DivisionCategory, on_delete=models.DO_NOTHING,
        null=True, blank=False, name='分類'
    )
    caseName = models.CharField(max_length=255, null=False, blank=False, name='案件名')
    modelName = models.CharField(max_length=255, null=False, blank=False, name='機種名型番')
    progressDetail = models.TextField(null=True, blank=True, name='進捗状況')
    location = models.ForeignKey(
        Location, on_delete=models.DO_NOTHING,
        null=True, blank=False, name='発生場所'
    )
    occurredAt = models.DateField(null=True, blank=True, name='発生日')
    defectSymptom = models.TextField(null=True, blank=True, name='不良症状内容')
    holdQty = models.PositiveBigIntegerField(null=False, blank=True, default=0, name='保留対象')
    recievedAt = models.DateField(null=True, blank=True, name='依頼日')
    stoppedAt = models.DateField(null=True, blank=True, name='停止日')
    releasedAt = models.DateField(null=True, blank=True, name='解除日')
    partStockQty = models.PositiveBigIntegerField(null=False, blank=True, default=0, name='単品在庫')
    wipStockQty = models.PositiveBigIntegerField(null=False, blank=True, default=0, name='半製品在庫')
    finishGoodStockQty = models.PositiveBigIntegerField(null=False, blank=True, default=0, name='完成品在庫')
    outerStockQty = models.PositiveBigIntegerField(null=False, blank=True, default=0, name='外部在庫')
    handlingContent = models.TextField(null=True, blank=True, name='対応内容')
    handlingPlanDate = models.DateField(null=True, blank=True, name='実施予定日')
    handlingActualDate = models.DateField(null=True, blank=True, name='実施実際日')
    handlingDepartment = models.ForeignKey(
        Department, on_delete=models.DO_NOTHING,
        null=True, blank=True, name='実施部署'
    )
    handlingUser = models.ForeignKey(
        AppUser, on_delete=models.CASCADE, 
        null=True, blank=True, related_name='実施者', name='実施者'
    )
    rootCause = models.TextField(null=True, blank=True, name='発生原因')
    omissionCause = models.TextField(null=True, blank=True, name='流出原因')
    analysisfiveWhy = models.TextField(null=True, blank=True, name='なぜなぜ')
    analysisPlanDate = models.DateField(null=True, blank=True, name='分析完了予定日')
    analysisActualDate = models.DateField(null=True, blank=True, name='分析完了実際日')
    occurrenceCounterMeasure = models.TextField(null=True, blank=True, name='是正処置発生対策')
    omissionCounterMeasure = models.TextField(null=True, blank=True, name='是正処置流出対策')
    preventionCounterMeasure = models.TextField(null=True, blank=True, name='是正処置再発防止')
    implementedPlanDate = models.DateField(null=True, blank=True, name='是正完了予定日')
    implementedActualDate = models.DateField(null=True, blank=True, name='是正完了実際日')
    caseClosedAt = models.DateField(null=True, blank=True, name='CLOSE日')
    history = AuditlogHistoryField()

    def get_absolute_url(self) -> str:
        return reverse('mqc:detail', kwargs={'pk': self.pk})
    
    def __str__(self):
        return '重大品質案件'
    
    class Meta:
        ordering = ['-発生日']

auditlog.register(MajorQualityCase)

from django.utils import timezone
from django.db.models.functions import ExtractMonth
import calendar
from collections import OrderedDict

def get_dataset_per_month_of_current_year() -> dict[str, typing.Any]:
    current_year = timezone.datetime.now().year
    field = '発生日'
    objs = (
        MajorQualityCase.objects
            .filter(発生日__isnull=False, 発生日__year=current_year)
            .values(field)
            .annotate(month=ExtractMonth(field))
            .values('month')
            .annotate(n=Count('pk'))
            .order_by('month')
    )
    month_counts_dict = OrderedDict(zip(range(1,13),[0]*12))
    month_counts_dict.update(dict(objs.values_list('month','n')))
    labels = []
    data = []
    for k, v in month_counts_dict.items():
        labels.append(calendar.month_name[k])
        data.append(v)
    category = 'Month'
    context = {
        'labels': list(labels),
        'data'  : list(data),
        'label': f'# per {category}',
        'title' : f'Major Quality Case per {category} of {current_year}',
    }
    return context

def get_dataset_per_division() -> dict[str, typing.Any]:
    field = '分類__name'
    objs = (
        MajorQualityCase.objects
            .filter(分類__isnull=False)
            .values(field)
            .annotate(
                division=F(field),
                n=Count('pk')
            )
    )
    labels = objs.values_list('division', flat=True)
    data = objs.values_list('n', flat=True)
    category = 'Divison'
    context = {
        'labels': list(labels),
        'data'  : list(data),
        'label': f'# of {category}',
        'title' : f'Major Quality Case per {category}',
    }
    return context

def get_dataset_per_partCategory() -> dict[str, typing.Any]:
    field = '製品分__name'
    objs = (
        MajorQualityCase.objects
            .filter(製品分__isnull=False)
            .values(field)
            .annotate(
                part=F(field),
                n=Count('pk')
            )
    )
    labels = objs.values_list('part', flat=True)
    data = objs.values_list('n', flat=True)
    category = 'Product'
    context = {
        'labels': list(labels),
        'data'  : list(data),
        'label': f'# of {category}',
        'title' : f'Major Quality Case per {category}',
    }
    return context

def get_dataset_per_responsibility() -> dict[str, typing.Any]:
    field = '責区__name'
    objs = (
        MajorQualityCase.objects
            .filter(責区__isnull=False)
            .values(field)
            .annotate(
                responsibility=F(field),
                n=Count('pk')
            )
    )
    labels = objs.values_list('responsibility', flat=True)
    data = objs.values_list('n', flat=True)
    category = 'Responsibility'
    context = {
        'labels': list(labels),
        'data'  : list(data),
        'label': f'# of {category}',
        'title' : f'Major Quality Case per {category}',
    }
    return context

def get_dataset_per_department() -> dict[str, typing.Any]:
    field = '実施部署__name'
    objs = (
        MajorQualityCase.objects
            .filter(実施部署__isnull=False)
            .values(field)
            .annotate(
                department=F(field),
                n=Count('pk')
            )
    )
    labels = objs.values_list('department', flat=True)
    data = objs.values_list('n', flat=True)
    category = 'Department'
    context = {
        'labels': list(labels),
        'data'  : list(data),
        'label': f'# of {category}',
        'title' : f'Major Quality Case per {category}',
    }
    return context

def get_dataset_per_location() -> dict[str, typing.Any]:
    field = '発生場所__name'
    objs = (
        MajorQualityCase.objects
            .filter(発生場所__isnull=False)
            .values(field)
            .annotate(
                location=F(field),
                n=Count('pk')
            )
    )
    labels = objs.values_list('location', flat=True)
    data = objs.values_list('n', flat=True)
    category = 'Location'
    context = {
        'labels': list(labels),
        'data'  : list(data),
        'label': f'# of {category}',
        'title' : f'Major Quality Case per {category}',
    }
    return context
