from rest_framework import serializers
from .models import MajorQualityCase

class MajorQualityCaseSerializer(serializers.ModelSerializer):
    責区 = serializers.CharField(source='責区.name')
    責任者 = serializers.CharField(source='責任者.username')
    製品分 = serializers.CharField(source='製品分.name')
    分類 = serializers.CharField(source='分類.name')
    発生場所 = serializers.CharField(source='発生場所.name')
    実施部署 = serializers.CharField(source='実施部署.name')
    実施者 = serializers.CharField(source='実施者.username')
    
    class Meta:
        model = MajorQualityCase
        fields = '__all__'