from django.apps import AppConfig


class MajorcaseConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'core.mqc'
