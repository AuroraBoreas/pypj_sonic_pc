import random, typing
import faker

from django.test import RequestFactory, TestCase
from django.urls import reverse

# from core.mqc.models import (MajorQualityCase, ResponsibilityCategory, PartCategory, AppUser, Department)
# from core.mqc.views import (MajorQualityCaseCreateView, MajorQualityCaseDeleteView, MajorQualityCaseDetailView, MajorQualityCaseUpdateView)

# def create_test_object_data() -> dict[str, typing.Any]:
#     fake = faker.Faker()
#     booleans = [True, False]
#     responsibilityCategories = ResponsibilityCategory.objects.create(fake.name)
#     partCategories = PartCategory.objects.create(fake.name())
#     users = AppUser.objects.create(name=fake.name())
#     locations = 'QC'
#     departments = Department.objects.create(fake.name())
#     return {
#         '進捗' : random.randint(0,100),
#         '市場発生' : random.choice(booleans),
#         '再発防止' : random.choice(booleans),
#         '出荷停止' : random.choice(booleans),
#         '責区' : random.choice(responsibilityCategories),
#         '責任者' : random.choice(users),
#         'TAT' : fake.date(),
#         '製品分' : random.choice(partCategories),
#         '案件名' : fake.sentence(random.randint(4, 10)),
#         '機種名型番' : fake.lexify(text='???').upper() + fake.numerify(text='##'),
#         '進捗状況' : fake.paragraph(),
#         '発生場所' : random.choice(locations),
#         '発生日' : fake.date(),
#         '不良症状内容' : fake.sentence(random.randint(4, 10)),
#         '保留対象' : random.randint(1, 10_000),
#         '依頼日' : fake.date(),
#         '停止日' : fake.date(),
#         '解除日' : fake.date(),
#         '単品在庫' : random.randint(1, 10_000),
#         '半製品在庫' : random.randint(1, 10_000),
#         '完成品在庫' : random.randint(1, 10_000),
#         '外部在庫' : random.randint(1, 10_000),
#         '対応内容' : fake.paragraph(),
#         '実施予定日' : fake.date(),
#         '実施実際日' : fake.date(),
#         '実施部署' : random.choice(departments),
#         '実施者' : random.choice(users),
#         '発生原因' : fake.paragraph(),
#         '流出原因' : fake.paragraph(),
#         'なぜなぜ' : fake.paragraph(),
#         '分析完了予定日' : fake.date(),
#         '分析完了実際日' : fake.date(),
#         '是正処置発生対策' : fake.paragraph(),
#         '是正処置流出対策' : fake.paragraph(),
#         '是正処置再発防止' : fake.paragraph(),
#         '是正完了予定日' : fake.date(),
#         '是正完了実際日' : fake.date(),
#         'CLOSE日' : fake.date()
#     }

class IndexViewTestCase(TestCase):
    def test_index_view(self) -> None:
        response = self.client.get(reverse('mqc:index'))
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'core/mqc/index.html')

class DashboardViewTestCase(TestCase):
    def test_dashboard_view(self) -> None:
        response = self.client.get(reverse('mqc:dashboard'))
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'core/mqc/dashboard.html')

class AdminViewTestCase(TestCase):
    def test_AdminView(self) -> None:
        response = self.client.get(reverse('admin:index'))
        self.assertEqual(response.status_code, 302)

class MajorQualityCaseListViewTestCase(TestCase):
    def test_MajorQualityCaseListView(self) -> None:
        response = self.client.get(reverse('mqc:dataset'))
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'core/mqc/data.html')

# from django.conf import settings
# from unittest.mock import patch
# import auditlog

# class MajorQualityCaseCreateViewTestCase(TestCase):
#     @patch('auditlog.context.auditlog_disabled', True)
#     def test_MajorQualityCaseCreateView(self) -> None:
#         data = create_test_object_data()
#         factory = RequestFactory()
#         request = factory.post(reverse('mqc:create'), data=data)
#         response = MajorQualityCaseCreateView.as_view()(request)
#         self.assertEqual(response.status_code, 302)
#         self.assertTrue(MajorQualityCase.objects.filter(責任者=data.get('責任者')).exists())

# class MajorQualityCaseUpdateViewTestCase(TestCase):
#     def test_MajorQualityCaseUpdateView(self) -> None:
#         obj = MajorQualityCase.objects.create(title='Object to Update')
#         factory = RequestFactory()
#         request = factory.post(reverse('your-update-view-url', kwargs={'pk': obj.pk}), data={'title': 'Updated Object'})
#         response = MajorQualityCaseUpdateView.as_view()(request, pk=obj.pk)
#         self.assertEqual(response.status_code, 302)
#         obj.refresh_from_db()
#         self.assertEqual(obj.title, 'Updated Object')

# class MajorQualityCaseDetailViewTestCase(TestCase):
#     def test_MajorQualityCaseDetailView(self) -> None:
#         obj = MajorQualityCase.objects.create(title='Test Object')
#         factory = RequestFactory()
#         request = factory.get(reverse('your-detail-view-url', kwargs={'pk': obj.pk}))
#         response = MajorQualityCaseDetailView.as_view()(request, pk=obj.pk)
#         self.assertEqual(response.status_code, 200)
#         self.assertContains(response, 'Test Object')

# class MajorQualityCaseDeleteViewTestCase(TestCase):
#     def test_MajorQualityCaseDeleteView(self) -> None:
#         obj = MajorQualityCase.objects.create(title='Object to Delete')
#         factory = RequestFactory()
#         request = factory.post(reverse('your-delete-view-url', kwargs={'pk': obj.pk}))
#         response = MajorQualityCaseDeleteView.as_view()(request, pk=obj.pk)
#         self.assertEqual(response.status_code, 302)
#         self.assertFalse(MajorQualityCase.objects.filter(pk=obj.pk).exists())