from .tests import (
    IndexViewTestCase,
    DashboardViewTestCase,
    AdminViewTestCase,
    MajorQualityCaseListViewTestCase,
    # MajorQualityCaseCreateViewTestCase
)