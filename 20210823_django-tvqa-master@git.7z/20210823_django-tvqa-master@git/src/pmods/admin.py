from django.contrib import admin
from .models import PMod
# Register your models here.

admin.site.register(PMod)