from django.contrib import admin
from .models import Feed

# Register your models here.
admin.site.register(Feed)