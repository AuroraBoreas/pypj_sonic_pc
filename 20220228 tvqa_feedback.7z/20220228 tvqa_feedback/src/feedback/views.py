from django.shortcuts import render, redirect
from django.contrib import messages
from django.db.models.functions import Upper
from django.db.models import Value

from .models import Feed
from .form import FeedRegisterForm


def contact_view(request):
    return render(request, template_name='contact.html')

def about_view(request):
    return render(request, template_name='about.html')

def get_client_ip(request):
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        ip = x_forwarded_for.split(',')[0]
    else:
        ip = request.META.get('REMOTE_ADDR')
    return ip

def feed_create_view(request, *args, **kwargs):
    if request.method == 'POST':
        form = FeedRegisterForm(request.POST)
        if form.is_valid():
            ip           = get_client_ip(request)
            title        = form.cleaned_data.get('title')
            date_created = form.cleaned_data.get('date_created')
            feed         = form.cleaned_data.get('feed')
            try:
                feeds = Feed.objects.filter(
                                        ip__iexact=ip,
                                        title__iexact=title,
                                        feed__iexact=feed,
                )
                # print(feeds)
            except Feed.DoesNotExist:
                feeds = None
            if feeds.exists():
                messages.warning(request, 'Feed existed already!')
                return redirect('feedback:home')
            else:
                feed_new = Feed(
                                ip=Upper(Value(ip)),
                                title=Upper(Value(title)),
                                date_created=Upper(Value(date_created)),
                                feed=Upper(Value(feed)),
                )
                feed_new.save()
                feed_new.refresh_from_db()
                messages.success(request, "Feed created successfully!")
                return redirect('feedback:home')
    else:
        form = FeedRegisterForm()
    context = {
        'form': form,
    }
    return render(request, template_name='feed_create.html', context=context)

def feed_list_view(request, *args, **kwargs):
    if request.method == 'GET':
        feeds = Feed.objects.all().order_by('-date_created')
        context = {
            'feeds': feeds,
        }
        return render(request, template_name='home.html', context=context)
    else:
        return render(request, template_name='home.html')