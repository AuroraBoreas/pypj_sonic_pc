from django.db import models
from django.utils import timezone

class Feed(models.Model):
    ip           = models.CharField(max_length=20)
    title        = models.CharField(max_length=50, blank=False, null=False)
    date_created = models.DateTimeField(default=timezone.datetime.today)
    feed         = models.TextField(max_length=400, blank=False, null=False)

    def __repr__(self):
        return 'PMod {}'.format(self.title)