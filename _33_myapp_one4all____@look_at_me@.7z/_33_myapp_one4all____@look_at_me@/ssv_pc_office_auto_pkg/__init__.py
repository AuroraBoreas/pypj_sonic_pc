__all__ = [
    'myapp_00_muracuc_batch',
    'myapp_01_ul_contract',
    'myapp_02_muracuc_gui',
    'myapp_03_Dino_ocr',
    'myapp_04_Optical_report',
    'myapp_05_FOS_report',
    'myapp_06_upload_email',
    'myapp_07_merge_cs2000_files',
    'myapp_08_kill_tmp_folders',
]