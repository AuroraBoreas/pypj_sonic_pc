```

this module is to create a powerpoint report template.
@ZL, 20210506

it includes the following functionalityies:

* UI
  ----------------------------------------------------
  | PMOD/ITC |  { placeholder }                      |
  | Event    |  { placeholder }                      |
  | Locality |  { placeholder }                      |
  | Copies   |  { placeholder }                      |
  ----------------------------------------------------

* Pages
  first page
  ----------------------------------------------------
  |                                                  |
  |   __________________________________________     |
  |  |  PMOD/ITC_Event Locality                 |    |
  |  |__________________________________________|    |
  |                                                  |
  ----------------------------------------------------
  
  second page
  ----------------------------------------------------
  | Title                                            |
  |--------------------------------------------------|
  | summary table                                    |
  | ---------------------------                      |
  | PMOD/ITC |  { placeholder }                      |
  | Event    |  { placeholder }                      |
  | DateTime |  { default = True }                   |
  | Locality |  { placeholder }                      |
  | Symptom  |  { placeholder }                      |
  | Ratio    |  { placeholder }                      |
  | R/C      |  { placeholder }                      |
  | C/M      |  { placeholder }                      |
  |                                                  |
  |  ____________________________________________    |
  | | conclusion textbox                         |   |
  | |____________________________________________|   |
  |                                                  |
  ----------------------------------------------------
  
  last page
  ----------------------------------------------------
  |                                                  |
  |  ___________________________________________     |
  | |           E.O.F                           |    |
  | |___________________________________________|    |
  |                                                  |
  ----------------------------------------------------

* utilities
  1 - [ save from memory to local disk ]
  2 - [ open the template ]

* other thoughts?
  ** format? font, text, color, display, grid?

```