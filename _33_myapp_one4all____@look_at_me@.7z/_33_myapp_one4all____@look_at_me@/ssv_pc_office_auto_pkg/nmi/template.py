"""
A simple powerpoint template class generates templates.

@ZL, 20210506

"""

import configparser
import datetime
import os
import pptx
from pptx.util import Cm, Pt
from tkinter import messagebox

def get_config(ini: str)->tuple:
    config = configparser.ConfigParser()
    config.read(ini)
    return config['default'].get('path'), config['default'].get('dir')

class PowerPointTemplate:
    ssvtemplate_first_page_index = 0
    ssvtemplate_six_page_index   = 5
    ssvtemplate_last_page_index  = 6
    today = datetime.datetime.now().strftime('%Y%m%d')

    def __init__(self, *args):
        """
        args[0] --> ssve_template;
        args[1] --> save;
        args[2] --> pmod;
        args[3] --> event;
        args[4] --> locality;
        args[5] --> copies;
        """
        self.args = args
        self.prs  = pptx.Presentation(args[0])
    
    def _iter_table(self, table):
        for row in table.rows:
            for cell in row.cells:
                yield cell

    def _change_entire_table_fontsize(self, table, fontsize=14):
        font_family = "Arial"
        for cell in self._iter_table(table):
            for paragraph in cell.text_frame.paragraphs:
                for run in paragraph.runs:
                    run.font.size = Pt(fontsize)
                    run.font.name = font_family
    
    def _first_page(self, pmod, event, locality):
        """first page"""
        layout     = self.prs.slide_layouts[self.ssvtemplate_first_page_index]
        slide      = self.prs.slides.add_slide(layout)
        title      = slide.shapes.title
        title.text = f"{pmod} {event} {locality}"

    def _second_page(self, pmod, event, locality):
        """second page"""
        layout = self.prs.slide_layouts[self.ssvtemplate_six_page_index]
        slide  = self.prs.slides.add_slide(layout)
        title  = slide.shapes.title
        title.text = "{} | {}".format(pmod, "{ }")

        # add summary table
        x, y, cx, cy = Cm(0.05), Cm(1.9), Cm(10), Cm(10)
        shape = slide.shapes.add_table(9, 2, x, y, cx, cy)
        table = shape.table
        table.columns[0].width = Cm(3)
        table.columns[1].width = Cm(6.8)

        table.cell(0, 0).text = 'Item'
        table.cell(0, 1).text = 'Detail'
        table.cell(1, 0).text = 'PMod/SET'
        table.cell(1, 1).text = pmod
        table.cell(2, 0).text = 'Event'
        table.cell(2, 1).text = event
        table.cell(3, 0).text = 'Datetime'
        table.cell(3, 1).text = self.today
        table.cell(4, 0).text = 'Locality'
        table.cell(4, 1).text = locality
        table.cell(5, 0).text = 'Symptom'
        table.cell(5, 1).text = '-'
        table.cell(6, 0).text = 'Ratio'
        table.cell(6, 1).text = 'pcs'
        table.cell(7, 0).text = 'R/C'
        table.cell(7, 1).text = 'TBD'
        table.cell(8, 0).text = 'C/M'
        table.cell(8, 1).text = 'TBD'

        self._change_entire_table_fontsize(table)

        # add fig.1
        x, y, cx, cy = Cm(10), Cm(.8), Cm(2), Cm(1)
        textbox = slide.shapes.add_textbox(x, y, cx, cy)
        tf = textbox.text_frame
        p = tf.add_paragraph()
        p.text = "Fig.1"
        p.font.size = Pt(14)
        p.font.name = "Arial Narrow"

        # add conclusion textbox
        x, y, cx, cy = Cm(10), Cm(17), Cm(20), Cm(1)
        textbox = slide.shapes.add_textbox(x, y, cx, cy)
        tf = textbox.text_frame
        p = tf.add_paragraph()
        p.text = "Conclusion: "
        p.font.size = Pt(18)
        p.font.name = "Arial"

    def _last_page(self):
        """final page"""
        layout = self.prs.slide_layouts[self.ssvtemplate_last_page_index]
        slide  = self.prs.slides.add_slide(layout)
        left, top, width, height= Cm(15), Cm(8), Cm(1), Cm(1)
        txtBox = slide.shapes.add_textbox(left, top, width, height)
        tf = txtBox.text_frame
        p  = tf.add_paragraph()
        p.text = "E.O.F"
        p.font.size = Pt(40)

    def _save(self):
        _, path, *rest = self.args
        dirname = "{} {}_{}_{}".format(self.today, *rest)
        dirpath = os.path.join(path, dirname)
        if not os.path.isdir(dirpath): os.makedirs(dirpath)
        fname = "{} {}_{}_{}.pptx".format(self.today, *rest)
        spath = os.path.join(dirpath, fname)
        try:
            self.prs.save(spath)
            os.startfile(spath)
        except PermissionError:
            messagebox.showinfo("Info", message="Failed: PPT report is open")  

    def build(self):
        _, _, *pel, n = self.args
        self._first_page(*pel)
        for i in range(int(n)):
            self._second_page(*pel)
        self._last_page()
        self._save()

if __name__ == '__main__':
    tmp_path  = r'C:\Users\5106001995\Desktop\_build_ppt_report_template\data\template.pptx'
    save_path = r"C:\Users\5106001995\Desktop"
    
    pt = PowerPointTemplate(tmp_path, save_path, "AG65", "APP", "LCM(S4)", 2)
    pt.build()
    # print(get_config(ini))
    # pt.build()