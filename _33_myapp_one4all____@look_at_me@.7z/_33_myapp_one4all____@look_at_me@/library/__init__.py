__all__ = [
    'mail',
    'powerpoint',
    'shoot_image',
]