"""

this module is specialization for sending PowerPoint Report via email

it contains the following functionalities:
- control PowerPoint Application
- view specific slides in order
- shoot image for each slide
- quit PowerPoint Application

about
- author: @ZL, 20201223

"""

import win32com.client as win32
import time, sys
sys.path.append('.')
from library.shoot_image import shoot_img

class ReportPowerPoint:
    __start_slide_no = 2
    __ulimit = 5
    __wait   = .5

    def __init__(self, strFile):
        self.__app               = win32.Dispatch('PowerPoint.application')
        self.__app.DisplayAlerts = False
        self.__app.Visible       = True
        self.__prs               = self.__app.Presentations.Open(strFile) # strFile MUST be an absolute path

    def quit(self):
        self.__app.Quit()

    def ttl_slides(self):
        return self.__prs.Slides.Count

    def shoot(self):
        if self.ttl_slides() < self.__ulimit:
            for i in range(self.__start_slide_no, self.ttl_slides()):
                self.__prs.Slides(i).Select()
                time.sleep(self.__wait)
                self.__prs.Slides(i).Select()
                # PPT, Zoom level: 70%
                shoot_img(f"images\\slide{i}.png", 443, 276, 1779, 1032) # depends on personal PC and PowerPoint application setting, YMMV
        else:
            # summary page only
            self.__prs.Slides(self.__start_slide_no).Select()
            time.sleep(self.__wait)
            self.__prs.Slides(self.__start_slide_no).Select()
            shoot_img(f"images\\slide{self.__start_slide_no}.png", 443, 276, 1779, 1032) # depends on personal PC and PowerPoint application setting, YMMV

if __name__ == "__main__":
    ppt_file = r"C:\Users\5106001995\Desktop\20210517 AG65_MP_LCM(A1)\20210517 AG65_MP_LCM(A1).pptx"
    ppt = ReportPowerPoint(ppt_file)
    ppt.shoot()
    ppt.quit()
