"""

this module is specialization for sending PowerPoint Report via email

it contains the following functionalities:
- control PowerPoint Application
- view specific slides in order
- shoot image for each slide
- quit PowerPoint Application

about
- author: @ZL, 20201223

"""

import win32com.client as win32
import time, sys
sys.path.append('.')
from library.shoot_image import shoot_img

class ReportPowerPoint:
    __start_slide_no = 2

    def __init__(self, strFile):
        self.__app               = win32.Dispatch('PowerPoint.application')
        self.__app.DisplayAlerts = False
        self.__app.Visible       = True
        self.__prs               = self.__app.Presentations.Open(strFile) # strFile MUST be an absolute path

    def quit(self):
        self.__app.Quit()

    def ttl_slides(self):
        return self.__prs.Slides.Count

    def shoot(self):
        for i in range(self.__start_slide_no, self.ttl_slides()):
            self.__prs.Slides(i).Select()
            time.sleep(.5)
            self.__prs.Slides(i).Select()
            # PPT, Zoom level: 70%
            shoot_img(f"images\\slide{i}.png", 443, 276, 1779, 1032) # depends on personal PC and PowerPoint application setting, YMMV

if __name__ == "__main__":
    ppt_file = r"D:\pj_00_codelib\2019_pypj\_102_ppt_to_mail\20201222 NX75_MP_Optical_Evaluation.pptx"
    ppt = ReportPowerPoint(ppt_file)
    ppt.shoot()
    ppt.quit()
