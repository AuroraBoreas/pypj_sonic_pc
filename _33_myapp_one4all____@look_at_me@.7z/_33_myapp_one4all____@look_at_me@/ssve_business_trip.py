# chinese
members = """
NAGAOKA KEIKO
NAGAOKA SAKURAKO
"""
purpose_cn = "帯同家族再渡航"


title_cn    = "NAGAOKA KEIKO&NAGAOKA SAKURAKO 帯同家族再渡航及费用审批"
bg_purp_cn  = """
目的:長岡謙一帯同家族再渡航費用申請 
NAGAOKA  KEIKO&NAGAOKA  SAKURAKO  帯同家族再渡航(期间:9/4/2020-9/4/2020)
""" 

# japanese
