import logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s %(message)s')

import pyautogui
import os, pathlib, subprocess, datetime, contextlib, time, functools, shutil
import platform, socket, re, uuid, json, psutil, sys, ctypes, glob
from typing import NewType, Callable, Any, Tuple
Path    = NewType('Path', str)
Process = NewType('Process', subprocess.Popen)
Date    = NewType('Date', datetime.date)

def shoot_img(str_img_name: str, x1: int, y1: int, x2: int, y2: int) -> None:
    """
    # shoot image for specific area
    take screenshot -> convert to binary data -> put on clipboard
    """
    w = x2 - x1
    h = y2 - y1
    pyautogui.screenshot(str_img_name, region=(x1, y1, w, h))

@contextlib.contextmanager
def temporary_process(exe_path: Path) -> Process:
    p = subprocess.Popen(exe_path)
    try:
        yield p
    finally:
        p.kill()

def timer(func: Callable) -> Callable:
    @functools.wraps(func)
    def inner(*args: Any, **kwargs: Any) -> Any:
        b: float = time.perf_counter()
        r: Any   = func(*args, **kwargs)
        e: float = time.perf_counter()
        logging.info('time lapsed(s) : {0:,.3f}'.format(e - b))
        return r
    return inner

def memoir(func: Callable) -> Callable:
    _cache = {}
    def memorized(*args: Any, **kwargs: Any) -> Any:
        key = (func.__name__, args.__hash__, kwargs.__hash__)
        if not key in _cache:
            _cache[key] = func(*args, **kwargs)
        return _cache[key]
    return memorized

class DevAuthorizor:
    @staticmethod
    def get_system_info() -> str:
        """a function retrieves system info

        :return: None
        :rtype: None
        """
        try:
            info = {}
            info['platform']         = platform.system()
            info['platform-release'] = platform.release()
            info['platform-version'] = platform.version()
            info['architecture']     = platform.machine()
            info['hostname']         = socket.gethostname()
            info['ip-address']       = socket.gethostbyname(socket.gethostname())
            info['mac-address']      = ':'.join(re.findall('..', '%012x' % uuid.getnode()))
            info['processor']        = platform.processor()
            info['ram']              = str(round(psutil.virtual_memory().total / (1024.0**3)))+" GB"
            info['python -V']        = sys.version
            info['screensize']       = ctypes.windll.user32.GetSystemMetrics(0), ctypes.windll.user32.GetSystemMetrics(1)
            return json.dumps(info)
        except Exception as e:
            logging.exception(e)

    @staticmethod
    def is_expired(expired_date: str='Dec 1 2020 8:00AM') -> bool:
        """a function decides where current date time ixpired

        :param expired_date: a datetime expired, defaults to 'Dec 1 2020 8:00AM'
        :type expired_date: str, optional
        :return: return true if expired or false if not
        :rtype: bool
        """
        ed  = datetime.datetime.strptime(expired_date,'%b %d %Y %I:%M%p')
        now = datetime.datetime.now()
        return (now - ed) > datetime.timedelta(days=1)

    def is_outdated(file_path: str, days: int=1) -> bool:
        mtime = pathlib.Path(file_path).stat().st_mtime
        mtime = datetime.datetime.fromtimestamp(mtime)
        now   = datetime.datetime.now()
        return (now - mtime) > datetime.timedelta(days=days)

class WeekNumber:
    @staticmethod
    def date2wkno(date_str: str) -> int:
        """return week number from a date string

        Args:
            date_str (str): date string. for example: '2021-08-21 00:00:00'

        Returns:
            int: yyww. for example: 2125
        """
        underscore = '_'
        slash = '/'
        if underscore in date_str:
            pfmt = "%Y-%m-%d %H:%M:%S"
        elif slash in date_str:
            pfmt = "%Y/%m/%d %H:%M:%S"
        else:
            pfmt = "%Y %m %d %H:%M:%S"

        d = datetime.datetime.strptime(date_str, pfmt).date()
        y = d.year % 100
        w = d.isocalendar()[1]
        fmt = "{}{}".format(y, w)
        return int(fmt)

    @staticmethod
    def wkno2ym(week_number: int, year: int) -> str:
        """return short yy mm from week number

        Args:
            week_number (int): week number. format is 2132. 21 shorts for 2021, 32 shorts for week number 32

        Returns:
            AnyStr: yy mm. for example: 21 Aug
        """

        i = 2 # index slices week_nummber: yyww
        d = 1 # pick monday as first day
        c = year // 100 * 100 # get first year of century

        cstr = str(week_number)
        y    = int(cstr[:i]) + c
        w    = cstr[i:]
        fmt  = "{}-{}-{}".format(y, w, d)
        d    = datetime.datetime.strptime(fmt, "%Y-%W-%w") # return yyyy-mm-dd
        return d.strftime("%y %b") # return short version yy-mm

    @staticmethod
    def GetBeginEndDateFromCalendarWeek(year: int, calendar_week: int) -> Tuple[Date,Date]:
        """return tuple[monday, sunday] from year, calendary week. for example: 2021, 32

        Args:
            year (int): natural year
            calendar_week (int): calendar week

        Returns:
            Tuple[Date,Date]: tuple

        """
        monday = datetime.datetime.strptime(f'{year}-{calendar_week}-1', "%Y-%W-%w").date()
        return monday, monday + datetime.timedelta(days=6.9)

class ServerUploader:
    def __init__(self, src_dir: Path, dst_dir: Path, host: str = '43.98.1.18', port: int = 445):
        """Upload files/folders recursively from a local folder to a server

        Args:
            - src_dir ([type]): source folder
            - dst_dir ([type]): destination folder
            - host (str, optional): where. Defaults to '43.98.1.18'.
            - port (int, optional): from which port. Defaults to 445.
        """
        self.src_dir = src_dir
        self.dst_dir = os.path.join(dst_dir, os.path.split(src_dir)[-1])
        self.host    = host
        self.port    = port

    def has_intranet(self, host: str, port: int, timeout: int=3):
        """check intranect connectivity"""
        try:
            socket.setdefaulttimeout(timeout)
            socket.socket(socket.AF_INET, socket.SOCK_STREAM).connect((host, port))
            return True
        except socket.error:
            return False

    def start(self):
        if self.has_intranet(self.host, self.port):
            shutil.copy_tree(self.src_dir, self.dst_dir)
            return True
        else:
            sys.exit("Warning: Lost connection")

class JpnCodebaseEncoder:
    """
    ======================possible encodings======================================================
    website: https://www.sljfaq.org/afaq/encodings.html
    python doc: https://docs.python.org/2.4/lib/standard-encodings.html

    #<~ JIS (Japanese Industrial Standard) character set:
    demerit ---> This is mainly a problem with JIS, since its revision process has been somewhat chaotic.
    scope ---> Shift JIS is the Microsoft encoding of JIS, standard on Windows and Mac systems. Almost all Japanese web pages used to be encoded in Shift JIS.
        EUC (EUC-JP) is the Unix encoding of JIS. It used to be standard on Linux/BSD systems, and is sometimes used on web pages.
        ISO-2022-JP is the 7-bit JIS encoding, that e-mails are usually sent in. It is rarely used in other contexts.

    #<~ Unicode
    merit ---> Unicode follows a policy that each new revision must be a strict super-set of previous ones, so version conflicts rarely cause problems.
    scope ---> UTF-8 is the Unicode encoding standard in Unix and on the internet
            and UTF-16 the Unicode encoding standard in Windows
            UTF-32 is mostly used for internal representation inside programs, and not for interchange.
    details --->
    JIS X 0201 - Roman characters (a, b, c ...) and half-width katakana only. Standard prefix: JG.
    JIS X 0208 - Core character set. 6355 kanji from level 1 and 2, 524 kana/punctuation/etc. Standard prefix: JH.
    JIS X 0212 - Supplemental characters. 5801 rare kanji, 266 non-English European characters. Standard prefix: JJ.
    JIS X 0213 - New unified character set. Sometimes called JIS2000, introduced in the year 2000, and meant to replace the 0208/0212 combination. It has no standard prefix.

    The above four JIS standards are the important ones, but for reference, here is the meaning of all the JIS X 200 codes:
        JIS X 0201 - Roman/katakana (JG)
        JIS X 0202 - ISO-2022-JP
        JIS X 0203, 0204, 0205, 0206, 0207 - Obsolete/withdrawn standards
        JIS X 0208 - Main kanji character set (JH)
        JIS X 0209 - How to write JIS X 0211 characters
        JIS X 0210 - How to encode numbers
        JIS X 0211 - Standard ASCII control codes
        JIS X 0212 - Supplemental character set (JJ)
        JIS X 0213 - New unified JIS character set
        JIS X 0218 - Definition of standard prefixes (JG, JH, JJ, JK, JL)
        JIS X 0221 - Unicode (JK for UCS-2, JL for UCS-4)

    cp932
    --->CP932 (code page 932) is an extension of Shift JIS from Microsoft. It adds the NEC/IBM extended characters. This extension is:
    NEC special characters (83 characters in SJIS row 13),
    NEC-selected IBM extended characters (374 characters in SJIS rows 89..92),
    and IBM extended characters (388 characters in SJIS rows 115..119).


    euc_jp, euc_jis_2004, euc_jisx0213
    --->EUC (Extended Unix Code), also known as UJIS, is an encoding which encodes all the characters of JIS X 0201, JIS X 0208 and JIS X 0212. It is compatible with ASCII, but not with JIS X 0201: EUC does not support 1-byte half-width katakana/punctuation (though it does support it in 2 bytes).

    iso2022_jp, iso2022_jp_1, iso2022_jp_2, iso2022_jp_2004, iso2022_jp_3, iso2022_jp_ext
    --->The most widely supported encoding for e-mail is the 7-bit ISO-2022-JP standard, which has been used for Japanese e-mail since the beginning. This encoding is almost certain to be understood by a Japanese recipient. It has also been standardized by the JSA under the name "JIS X 0202".


    shift-jis
    --->Shift JIS is an encoding of the JIS standard which was the standard encoding for Japanese on Microsoft and Apple computers before the advent of Unicode. The selling point of Shift JIS (a.k.a. SJIS) is that, unlike EUC, it is backwards-compatible with not only ASCII, but also JIS X 0201, so Shift JIS can be used to encode both JIS X 0201 and JIS X 0208 (but not JIS X 0212). One-byte half-width katakana/punctuation is valid Shift JIS. Unfortunately, this compatibility means that Shift JIS is the messiest encoding of all.

    so, when trying to convert VBA modules origated from SONY JP, the best decoding methods in windows are:
    shift_jis_2004 or shift_jisx0213 > shift_jis >  cp932

    =============================================================================================
    """

    @staticmethod
    def decode(file_path: str, encoding: str, save2fd_path: str) -> None:
        fn = os.path.split(file_path)[-1]
        save2file_path = os.path.join(save2fd_path, fn)
        with open(file_path, 'r', encoding=encoding) as srcf, open(save2file_path, 'w', encoding='utf-8') as f:
            for line in srcf.read():
                f.write(line)
        return
    
    @staticmethod
    def reencode(fd_path: str) -> None:
        chrset = ['shift_jis_2004', 'shift_jisx0213', 'shift_jis', 'cp932']
        src_fd_path = os.path.abspath(os.path.join(fd_path, "vba_mod_src"))
        save2fd_path = os.path.join(fd_path, "converted2fd")
        
        if not os.path.isdir(save2fd_path): os.makedirs(save2fd_path, exist_ok=True)
        src_files = sorted(glob.glob(os.path.join(src_fd_path, '*.bas')))
        encoding = chrset[-1]
        for f in src_files:
            JpnCodebaseEncoder.decode(f, encoding, save2fd_path)

if __name__ == '__main__':
    # shoot_img("hello.png", 10, 10, 100, 100)

    # today = "2021/06/27 09:15:32"
    # logging.info(WeekNumber.date2wkno(today))

    # week_number = 2132
    # d = WeekNumber.wkno2ym(week_number, 1985)
    # logging.info("week number('{0}') -> {1}".format(week_number, d))
    # logging.info("start date: {}, end date: {}".format(*WeekNumber.GetBeginEndDateFromCalendarWeek(2021, 1)))
    pass