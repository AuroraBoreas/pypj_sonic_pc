import os, contextlib, traceback
import win32com.client
from typing import NewType, TypeVar
Path  = NewType('Path', str)
Excel = TypeVar('Excel')

class Runner:
    """
    this module enables running excel macro via python.
    it bridges communication and integration python and vba.

    functionalities
    - get excel application instance
    - get workbook instance
    - run marco in the workbook instance

    author
    - @ZL, 20210821

    changelog
    - v0.01, initial build

    Ref:
    https://stackoverflow.com/questions/19616205/running-an-excel-macro-via-python
    https://stackoverflow.com/questions/49904045/win32com-save-as-variable-name-in-python-3-6

    """
    @contextlib.contextmanager
    def open_excel() -> Excel:
        """return excel application object

        Yields:
            [type]: excel application object

        """
        excel = win32com.client.Dispatch("Excel.Application")
        excel.Visible = False
        try:
            yield excel
        finally:
            # excel.Application.Save() # if you want to save then uncomment this line and change delete the ", ReadOnly=1" part from the open function.
            excel.Application.Quit()
            del excel

    @contextlib.contextmanager
    def open_workbook(excel: Excel, xl_file: Path) -> None:
        """return workbook object via excel application

        Args:
            excel ([type]): excel application object
            xl_file ([type]): excel file(*.xlsm) that contains macro

        Yields:
            [type]: workbook object
            
        """
        xl_file  = os.path.expanduser(xl_file)
        workbook = excel.Workbooks.Open(Filename=xl_file, ReadOnly=1)
        try:
            yield workbook
        finally:
            # workbook.Save()
            workbook.Close(False)

def call_vba_macro(xl_file: Path, macro_name: str) -> None:
    """call vba macro to complement miss data and summarize inputs, due to time efficiency
    vba is much faster than python + xlrd
    """
    macro_addr = "\'{0}\'!{1}".format(xl_file, macro_name)
    if os.path.exists(xl_file):
        with Runner.open_excel() as excel:
            try:
                with Runner.open_workbook(excel, xl_file) as workbook:
                    # possible workbook usage
                    excel.Application.Run(macro_addr) # run macro in the workbook
            except Exception as e:
                # print(xl_file)
                traceback.print_exc()

if __name__ == '__main__':
    # ~ xl_file must be an absolute path
    # preprocess_xl = r'D:\pj_00_codelib\2019_pypj\20210805_WW_Pmod_SMLD_Control_System\lib\vba\WWPmodSMLDWrangler.xlsm'
    # macro_name = "Module1.CPModWrangler"
    # call_vba_macro(preprocess_xl, macro_name)
    pass