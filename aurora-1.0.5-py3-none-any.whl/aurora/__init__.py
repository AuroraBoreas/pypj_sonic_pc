from .cie import CIE
from .emailer import MailReporter
from .ppter import PowerPointReporter

from .imager import (
    Excel_Image_Extractor,
    MuraImageLoader,
    Path,
    Workbook,
    open_workbook,
)

from .macro import (
    Runner,
    call_vba_macro
)

from .translator import (
    AzureTranslator
)

from .utils import (
    shoot_img,
    temporary_process,
    timer,
    memoir,
    DevAuthorizor,
    WeekNumber,
    ServerUploader,
    JpnCodebaseEncoder,
)

class Facade:
    @staticmethod
    def make_email_reporter(ppt_name: str, dst_dir: str, slide_img_folder: str, src_ppt_file: str, reciever = "Liang.Zhang@sony.com") -> MailReporter:
        """

        Args:
            - ppt_name (str): powerpoint file name, which will be sent via email
            - dst_dir (str): server folder where stores raw data
            - slide_img_folder (str): where to store slide shoot image
            - src_ppt_file (str): source powerpoint file
            - reciever (str, optional): Email address. Defaults to "Liang.Zhang@sony.com".

        Returns:
            MailReporter: [description]
        """
        return MailReporter(ppt_name, dst_dir, slide_img_folder, src_ppt_file, reciever)

    @staticmethod
    def make_ppt_reporter(strFile: str, slide_img_folder: str) -> PowerPointReporter:
        """

        Args:
            strFile (str): source powerpoint file
            slide_img_folder (str): a folder where stores slide shoot images

        Returns:
            PowerPointReporter: [description]
        """
        return PowerPointReporter(strFile, slide_img_folder)

    @staticmethod
    def make_excel_image_extractor(
        wb_path: str,
        ws_name: str,
        target_address: str,
        target_name: str,
        tmp_img_folder: str
    ) -> Excel_Image_Extractor:
        """extract images from given addresses in a given worksheet of a given excel workbook

        Args:
            - wb_path (str): path-like string
            - ws_name (str): worksheet name, string
            - target_address (str): excel range style
            - target_name (str): image name
            - tmp_img_folder (str): save folder

        Returns:
            Excel_Image_Extractor: [description]
        """
        return Excel_Image_Extractor(wb_path, ws_name, target_address, target_name, tmp_img_folder)

    @staticmethod
    def make_excel_image_loader(
        xl_template: Path,
        dst_xl: Path,
        img_folder: Path,
        width: int,
        dstCellName: str,
        dstCellCol896: str,
        dstCellCol896R: str
    ) -> MuraImageLoader:
        """load MuraCUC images into excel

        Args:
            - xl_template (Path): a formatted excel report template
            - dst_xl (Path): save to excel path
            - img_folder (Path): where are images
            - width (int): image width in final report, it changes dimension of images when looding
            - dstCellName (str): load to which cell, anchor
            - dstCellCol896 (str): which column stores 896 before adjustment
            - dstCellCol896R (str): which column stores 896 after adjustment

        Returns:
            MuraImageLoader: [description]
        """
        return MuraImageLoader(xl_template, dst_xl, img_folder, width, dstCellName, dstCellCol896, dstCellCol896R)

    @staticmethod
    def make_cie_converter(a: float, b: float, color_space: str) -> CIE:
        """
        Args:
            - param a: x or u'
            - type a: float
            - param b: y or v'
            - type b: float
            - param color_space: CIE1931(x, y) or CIE1976(u', v')
            - type color_space: str

        Returns:
            CIE_Converter: [description]
        """
        return CIE(a, b, color_space)

__all__ = [
    CIE,
    MailReporter,
    PowerPointReporter,
    Excel_Image_Extractor,
    MuraImageLoader,
    Path,
    Workbook,
    open_workbook,
    Runner,
    call_vba_macro,
    AzureTranslator,
    shoot_img,
    temporary_process,
    timer,
    memoir,
    DevAuthorizor,
    WeekNumber,
    ServerUploader,
    JpnCodebaseEncoder,
    Facade,
]