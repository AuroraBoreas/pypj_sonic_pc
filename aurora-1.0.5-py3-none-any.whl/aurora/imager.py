import win32com.client as win32
import openpyxl
from ctypes import windll
import os, sys, pathlib, contextlib, logging
from PIL import Image, ImageGrab
logging.basicConfig(level=logging.INFO, format='%(asctime)s %(message)s')
from typing import NewType, List, TypeVar
Path     = NewType('Path', str)
Workbook = TypeVar('Workbook')

class Excel_Image_Extractor:
    def __init__(self, wb_path: str, ws_name: str, target_address: str, target_name: str, tmp_img_folder: str) -> None:
        """extract images from given addresses in a given worksheet of a given excel workbook

        Args:
            - wb_path (str): path-like string
            - ws_name (str): worksheet name, string
            - target_address (str): excel range style
            - target_name (str): image name
            - tmp_img_folder (str): save folder
        """
        self.wb_path     = wb_path #<~ must be a absolute full path
        self.ws_name     = ws_name
        self.rng_address = target_address
        self.rng_name    = target_name
        self.img_folder  = tmp_img_folder

        self.xlapp               = win32.DispatchEx('Excel.Application') #NOT work if Excel application is not registered
        self.xlapp.DisplayAlerts = False
        self.xlapp.Visible       = False

    def __clear_clipboard(self) -> None:
        ##<~~clear clipboard and quit XL application
        if windll.user32.OpenClipboard(None):
            windll.user32.EmptyClipboard()
            windll.user32.CloseClipboard()

    def start(self, screenshotonly: bool=False) -> None:
        wb = self.xlapp.Workbooks.Open(self.wb_path)
        ws = wb.Worksheets(self.ws_name)
        try:
            rng = ws.Range(self.rng_address)
            rng.Copy()
            img = ImageGrab.grabclipboard()
            img.save(os.path.join(self.img_folder, "{}.jpg".format(self.rng_name)), 'jpeg')

            if not screenshotonly:
                for _, shape in enumerate(ws.Shapes):
                    if shape.Name.startswith('Graph'):
                        shape.Copy()
                        img = ImageGrab.grabclipboard()
                        img.save(os.path.join(self.img_folder, "{}.jpg".format(shape.Name)), 'jpeg')

        except AttributeError:
            sys.exit("Failed to grab img from XL file {}".format(self.wb_path))
        finally:
            self.__clear_clipboard()
            wb.Close(False)
        return

    def quit(self) -> None:
        self.xlapp.Quit()

@contextlib.contextmanager
def open_workbook(wb_path: Path, dst_path: Path) -> Workbook:
    wb = openpyxl.load_workbook(wb_path)
    try:
        yield wb
    finally:
        wb.save(dst_path)
        wb.close()

class MuraImageLoader:
    """
    this module loads Mura Images into an excel template;

    it has the following functionalities
    - sort images from a given source image folder
    - open template excel workbook
    - load resized images into specific columns in the workbook

    author
    - @ZL, 20210828

    changelog
    - v0.01, initial build

    Ref links:
    - https://stackoverflow.com/questions/51591634/fill-a-image-in-a-cell-excel-using-python
    - https://stackoverflow.com/questions/2232742/does-python-pil-resize-maintain-the-aspect-ratio
    - https://stackoverflow.com/questions/1405602/how-to-adjust-the-quality-of-a-resized-image-in-python-imaging-library

    """
    
    img_ext               = '.bmp'
    muradata896           = 'mesdata896_'
    muradata896SOEM       = 'mesdata2_'
    muradataresult896     = 'mesdata896result_'
    muradataresult896SOEM = 'mesdata2result_'
    dstStartRow           = 2
    img_quality           = 95

    def __init__(self, xl_template:Path, dst_xl:Path, img_folder:Path, width:int, dstCellName:str, dstCellCol896:str, dstCellCol896R:str):
        """load MuraCUC images into excel

        Args:
            - xl_template (Path): a formatted excel report template
            - dst_xl (Path): save to excel path
            - img_folder (Path): where are images
            - width (int): image width in final report, it changes dimension of images when looding
            - dstCellName (str): load to which cell, anchor
            - dstCellCol896 (str): which column stores 896 before adjustment
            - dstCellCol896R (str): which column stores 896 after adjustment
        """
        self._xl_template     = xl_template
        self._dst_xl          = dst_xl
        self._img_folder      = img_folder
        self.width            = width
        self.dstCellName      = dstCellName
        self.dstCellCol896    = dstCellCol896
        self.dstCellCol896R   = dstCellCol896R
        self._896:List[Path]  = []
        self._896R:List[Path] = []

    def _sort_images(self)->None:
        for root, _, files in os.walk(self._img_folder):
            for file in files:
                if file.endswith(self.img_ext):
                    filepath = os.path.join(root, file)
                    if self.muradata896 in file.lower() or self.muradata896SOEM in file.lower():
                        self._896.append(filepath)
                    if self.muradataresult896 in file.lower() or self.muradataresult896SOEM in file.lower():
                        self._896R.append(filepath)
        if not(len(self._896) == len(self._896R) and len(self._896) > 0 and len(self._896R) > 0):
            raise ValueError("Before/After QTY::SRC_Images Not Match, _896 = {}, _896Result = {}".format(len(self._896), len(self._896R)))

    def _is_pmod_id_match(self, x:str, y:str)->bool:
        delimiter = '_'
        idx_id    = 2
        return x.split(delimiter)[idx_id] == y.split(delimiter)[idx_id]

    def _export(self)->None:
        idx_w, idx_h = (0, 1)
        i = j = self.dstStartRow

        with open_workbook(self._xl_template, self._dst_xl) as wb:
            ws = wb.worksheets[0]
            ub = len(self._896)
            for k in range(0, ub):
                img_896  = self._896[k]
                img_896R = self._896R[k]
                if not self._is_pmod_id_match(img_896, img_896R):
                    raise FileNotFoundError(f"Pair {self.muradata896}:{self.muradataresult896}, PmodID Not Match by")
                
                img = Image.open(img_896)
                width_percent = (self.width/float(img.size[idx_w]))
                hsize = int((float(img.size[idx_h])*float(width_percent)))
                img = img.resize((self.width, hsize), Image.ANTIALIAS)
                pmod_name = os.path.split(img_896)[-1]
                img_addr = f'tmp_{pmod_name}.png'
                img.save(img_addr, quality=self.img_quality)
                img896 = openpyxl.drawing.image.Image(img_addr)
                dstCellAddress = f'{self.dstCellName}{i}'
                ws[dstCellAddress].value = pmod_name # pmod/SET name
                dstCellAddress = f'{self.dstCellCol896}{i}'
                ws.add_image(img896, dstCellAddress)
                i += 1

                img = Image.open(img_896R)
                img = img.resize((self.width, hsize), Image.ANTIALIAS)
                pmod_name = os.path.split(img_896R)[-1]
                img_addr = f'tmp_R{pmod_name}.png'
                img.save(img_addr, quality=self.img_quality)
                img896R = openpyxl.drawing.image.Image(img_addr)
                dstCellAddress = f'{self.dstCellCol896R}{j}'
                ws.add_image(img896R, dstCellAddress)
                j += 1

    def clean_tmp_imgs(self):
        p = pathlib.Path('.')
        for f in p.glob('*.bin.bmp.png'):
            pathlib.Path.unlink(f)

    def clean(self)->None:
        self._896.clear()
        self._896R.clear()
        self.clean_tmp_imgs()

    def work(self)->None:
        self._sort_images()
        self._export()
        self.clean()

if __name__ == '__main__':
    # wb_path = "01.Brightness & chromaticity_jis_NX65.xlsm"
    # wb_path = r"C:\Users\5106001995\Desktop\20201222 NX75_QC_Optical_NG\00_Brightness & chromaticity_NX75_MP.xlsm"
    # tmp_fd  = r"C:\Users\5106001995\Desktop\temp"
    # xi = Excel_Image_Extractor(wb_path, "report", "C4:K13", "summary", tmp_fd)
    # xi.start()
    # xi.quit()

    # 
    # template       = r'D:\pj_00_codelib\2019_pypj\20210830 TV_Pmod_Mura_Correction_Checker\templates\Mura_List_Template.xlsx'
    # dst_xl         = r'D:\pj_00_codelib\2019_pypj\20210830 TV_Pmod_Mura_Correction_Checker\test1.xlsx'
    # src_img_folder = r'D:\pj_00_codelib\2019_pypj\20210830 TV_Pmod_Mura_Correction_Checker\Images'
    # dstWidth       = 240
    # dstCellName    = 'B'
    # dstCellCol896  = 'C'
    # dstCellCol896R = 'D'
    # mil = MuraImageLoader(template, dst_xl, src_img_folder, dstWidth, dstCellName, dstCellCol896, dstCellCol896R)
    # mil.work()
    # mil.clean()
    pass